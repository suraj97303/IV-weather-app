
# Weather-app

## Description:

This web application fulfill the purpose of retrieving data from another application's API to provide 5 days of forecast saved with localstorage.

## Installation:

No special packages needed. It runs with vanilla javascript.

## Usage:

By accessing the website and typing in the city in lowercase, you can find the current weather conditions as well as forecasts for the following 5 days.


## Link:




## For additional questions:


### 📫 &nbsp; How to reach me:



<a href="https://www.linkedin.com/in/vinod-kuril-6398b5220/"><img alt="LinkedIn" src="https://img.shields.io/badge/linkedin%20-%230077B5.svg?&style=flat&logo=linkedin&logoColor=white"/></a> &nbsp;
<a href="https://www.instagram.com/vinodkuril_17/?hl=en"><img src="https://img.shields.io/badge/-@vinodkuril_17-E4405F?style=flat&logo=Instagram&logoColor=white"/></a> &nbsp;
<a href="mailto:kurilvinod9870@gmail.com"><img alt="Gmail" src="https://img.shields.io/badge/Gmail-D14836?style=flat&logo=gmail&logoColor=white" /></a> &nbsp;


 
